﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MovieTracker.Tests.Unit.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {

    }
}
